package v4;

public class Dokter {
  private String namaDokter;
  private String tugasDokter;
  private int biayaDokter;

  public void Perawatan(String namaDokter, String tugasDokter, int biayaDokter) {
    this.namaDokter = namaDokter;
    this.tugasDokter = tugasDokter;
    this.biayaDokter = biayaDokter;
  }

  public String getNamaDokter() {
    return namaDokter;
  }

  public String getTugasDokter() {
    return tugasDokter;
  }

  public int getBiayaDokter() {
    return biayaDokter;
  }
}