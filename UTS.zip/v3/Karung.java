package v3;

public class Karung {
  private String ukuranKarung;
  private int biayaPeminjaman;
  private int bunga;
  private int kewajibanBulanan;
  private int totalPeminjamanKarung;

  public void Perawatan(String ukuranKarung, int biayaPeminjaman, int bunga, int kewajibanBulanan, int totalPeminjamanKarung) {
    this.ukuranKarung = ukuranKarung;
    this.biayaPeminjaman = biayaPeminjaman;
    this.bunga = bunga;
    this.kewajibanBulanan = kewajibanBulanan;
    this.totalPeminjamanKarung = totalPeminjamanKarung;
  }

  public String getUkuranKarung() {
    return ukuranKarung;
  }

  public int getBiayaPeminjaman() {
    return biayaPeminjaman;
  }

  public int getBunga() {
    return bunga;
  }

  public int getKewajibanBulanan() {
    return kewajibanBulanan;
  }

  public int totalPeminjamanKarung() {
    return biayaPeminjaman + kewajibanBulanan;
  }
}