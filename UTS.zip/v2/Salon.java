package v2;

import java.util.ArrayList;
import java.util.Scanner;

public class Salon {
  public static void main(String[] args) {
    Scanner inputan = new Scanner(System.in);

    Perawatan perawatan = new Perawatan();
    Sewa sewa = new Sewa();

    String namaPelanggan;
    long noTelepon;

    ArrayList<String> menu = new ArrayList<String>();
    menu.add("");
    menu.add("Perawatan");
    menu.add("Penyewaan");
    
    ArrayList<String> menuJenisPerawatan = new ArrayList<String>();
    menuJenisPerawatan.add("");
    menuJenisPerawatan.add("Facial Wajah");
    menuJenisPerawatan.add("Masker");
    menuJenisPerawatan.add("Potong Rambut");

    ArrayList<String> menuFacialWajah = new ArrayList<String>();
    menuFacialWajah.add("");
    menuFacialWajah.add("Facial Biasa");
    menuFacialWajah.add("Facial Emas");

    ArrayList<String> menuMasker = new ArrayList<String>();
    menuMasker.add("");
    menuMasker.add("Masker Buah");
    menuMasker.add("Masker Lumpur");

    ArrayList<String> menuPotonganRambut = new ArrayList<String>();
    menuPotonganRambut.add("");
    menuPotonganRambut.add("Tidak Keramas");
    menuPotonganRambut.add("Keramas");
    
    ArrayList<String> menuJenisSewa = new ArrayList<String>();
    menuJenisSewa.add("");
    menuJenisSewa.add("Rias Wajah");
    menuJenisSewa.add("Baju Pengantin");
    menuJenisSewa.add("Aksesoris");

    ArrayList<String> menuRiasWajah = new ArrayList<String>();
    menuRiasWajah.add("");
    menuRiasWajah.add("Rias Wajah Biasa");
    menuRiasWajah.add("Rias Wajah (Make Up Artis)");

    ArrayList<String> menuBajuPengantin = new ArrayList<String>();
    menuBajuPengantin.add("");
    menuBajuPengantin.add("Baju Pengatin Adat");
    menuBajuPengantin.add("Baju Pengantin Internasional");

    ArrayList<String> menuAksesoris = new ArrayList<String>();
    menuAksesoris.add("");
    menuAksesoris.add("Aksesoris Anak");
    menuAksesoris.add("Aksesoris Dewasa");

    System.out.println("---- Selamat Datang di Salon Cantika ----");
    System.out.println("=========================================");
    System.out.println();
    
    System.out.print("Nama Pelanggan: ");
    namaPelanggan = inputan.nextLine();
    System.out.print("No. Telepon: ");
    noTelepon = inputan.nextLong();
    String dummy = inputan.nextLine();

    System.out.println();
    System.out.println("------------------o0o--------------------");
    System.out.print("Lakukan Transaksi [y/t] ? ");
    String pilihanTransaksi = inputan.nextLine();
    System.out.println("------------------o0o--------------------");
    System.out.println();

    if (pilihanTransaksi.equals("y")) {
      System.out.println("Menu Pilihan yang Tersedia: ");

      for (int i = 1; i < menu.size(); i++) {
        System.out.println(i + ". " + menu.get(i));
      }

      System.out.println();
      System.out.println("------------------o0o--------------------");
      System.out.print("Pilihan Menu: ");
      int pilihanMenu = inputan.nextInt();
      System.out.println("------------------o0o--------------------");
      System.out.println();

      if (pilihanMenu == 1) {
        System.out.println("* Jenis Perawatan *");
        
        for (int i = 1; i < menuJenisPerawatan.size(); i++) {
          System.out.println(i + ". " + menuJenisPerawatan.get(i));
        }

        System.out.println();
        System.out.println("------------------o0o--------------------");
        System.out.print("Pilihan Anda: ");
        int pilihanMenuJenisPerawatan = inputan.nextInt();
        System.out.println("------------------o0o--------------------");
        System.out.println();

        if (pilihanMenuJenisPerawatan == 1) {
          System.out.println("===== Menu Facial Wajah ======");

          for (int i = 1; i < menuFacialWajah.size(); i++) {
            System.out.println(i + ". " + menuFacialWajah.get(i) + " Rp. ");
          }

          System.out.println();
          System.out.println("------------------o0o--------------------");
          System.out.print("Pilihan Anda: ");
          int pilihanMenuFacialWajah = inputan.nextInt();
          System.out.println("------------------o0o--------------------");
          System.out.println();

          if (pilihanMenuFacialWajah == 1) {
            String jenisPerawatan = "Facial Wajah";
            String jenisMenuPerawatan = "Facial Biasa";

            System.out.print("Berapa Orang: ");
            int jumlahOrangPerawatan = inputan.nextInt();
            
            perawatan.Perawatan(jenisPerawatan, jenisMenuPerawatan, perawatan.getHargaPerawatan(), jumlahOrangPerawatan);

            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + perawatan.getHargaPerawatan());
          } else if (pilihanMenuFacialWajah == 2) {
            String jenisPerawatan = "Facial Wajah";
            String jenisMenuPerawatan = "Facial Biasa";

            System.out.print("Berapa Orang: ");
            int jumlahOrangPerawatan = inputan.nextInt();

            perawatan.Perawatan(jenisPerawatan, jenisMenuPerawatan, perawatan.getHargaPerawatan(), jumlahOrangPerawatan);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + perawatan.getHargaPerawatan());
          }          
        } else if (pilihanMenuJenisPerawatan == 2) {
          System.out.println("===== Menu Masker ======");

          for (int i = 1; i < menuMasker.size(); i++) {
            System.out.println(i + ". " + menuMasker.get(i));
          }

          System.out.println();
          System.out.println("------------------o0o--------------------");
          System.out.print("Pilihan Anda: ");
          int pilihanMenuMasker = inputan.nextInt();
          System.out.println("------------------o0o--------------------");
          System.out.println();

          if (pilihanMenuMasker == 1) {
            String jenisPerawatan = "Facial Wajah";
            String jenisMenuPerawatan = "Facial Biasa";

            System.out.print("Berapa Orang: ");
            int jumlahOrangPerawatan = inputan.nextInt();

            perawatan.Perawatan(jenisPerawatan, jenisMenuPerawatan, perawatan.getHargaPerawatan(), jumlahOrangPerawatan);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + perawatan.getHargaPerawatan());
          } else if (pilihanMenuMasker == 2) {
            String jenisPerawatan = "Facial Wajah";
            String jenisMenuPerawatan = "Facial Biasa";

            System.out.print("Berapa Orang: ");
            int jumlahOrangPerawatan = inputan.nextInt();

            perawatan.Perawatan(jenisPerawatan, jenisMenuPerawatan, perawatan.getHargaPerawatan(), jumlahOrangPerawatan);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + perawatan.getHargaPerawatan());
          }          
        } else if (pilihanMenuJenisPerawatan == 3) {
          System.out.println("===== Menu Potongan Rambut ======");

          for (int i = 1; i < menuPotonganRambut.size(); i++) {
            System.out.println(i + ". " + menuPotonganRambut.get(i));
          }

          System.out.println();
          System.out.println("------------------o0o--------------------");
          System.out.print("Pilihan Anda: ");
          int pilihanMenuPotongRambut = inputan.nextInt();
          System.out.println("------------------o0o--------------------");
          System.out.println();

          if (pilihanMenuPotongRambut == 1) {
            String jenisPerawatan = "Facial Wajah";
            String jenisMenuPerawatan = "Facial Biasa";

            System.out.print("Berapa Orang: ");
            int jumlahOrangPerawatan = inputan.nextInt();

            perawatan.Perawatan(jenisPerawatan, jenisMenuPerawatan, perawatan.getHargaPerawatan(), jumlahOrangPerawatan);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + perawatan.getHargaPerawatan());
          } else if (pilihanMenuPotongRambut == 2) {
            String jenisPerawatan = "Facial Wajah";
            String jenisMenuPerawatan = "Facial Biasa";

            System.out.print("Berapa Orang: ");
            int jumlahOrangPerawatan = inputan.nextInt();

            perawatan.Perawatan(jenisPerawatan, jenisMenuPerawatan, perawatan.getHargaPerawatan(), jumlahOrangPerawatan);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + perawatan.getHargaPerawatan());
          }
        }
      } else if (pilihanMenu == 2) {
        System.out.println("* Jenis Penyewaan *");
        
        for (int i = 1; i < menuJenisSewa.size(); i++) {
          System.out.println(i + ". " + menuJenisSewa.get(i));
        }

        System.out.println();
        System.out.println("------------------o0o--------------------");
        System.out.print("Pilihan Anda: ");
        int pilihanMenuJenisSewa = inputan.nextInt();
        System.out.println("------------------o0o--------------------");
        System.out.println();

        if (pilihanMenuJenisSewa == 1) {
          System.out.println("===== Menu Rias Wajah ======");

          for (int i = 1; i < menuRiasWajah.size(); i++) {
            System.out.println(i + ". " + menuRiasWajah.get(i) + " Rp. ");
          }

          System.out.println();
          System.out.println("------------------o0o--------------------");
          System.out.print("Pilihan Anda: ");
          int pilihanMenuRiasWajah = inputan.nextInt();
          System.out.println("------------------o0o--------------------");
          System.out.println();

          if (pilihanMenuRiasWajah == 1) {
            String jenisSewa = "Rias Wajah";
            String jenisMenuSewa = "Rias Wajah Biasa";

            System.out.print("Jam Sewa: ");
            int jamSewa = inputan.nextInt();
            
            sewa.Sewa(jenisSewa, jenisMenuSewa, sewa.getHargaSewa(), jamSewa);

            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + sewa.getHargaSewa());
          } else if (pilihanMenuRiasWajah == 2) {
            String jenisSewa = "Rias Wajah";
            String jenisMenuSewa = "Rias Wajah (Make Up Artis)";

            System.out.print("Jam Sewa: ");
            int jamSewa = inputan.nextInt();

            sewa.Sewa(jenisSewa, jenisMenuSewa, sewa.getHargaSewa(), jamSewa);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + sewa.getHargaSewa());
          }          
        } else if (pilihanMenuJenisSewa == 2) {
          System.out.println("===== Menu Baju Pengantin ======");

          for (int i = 1; i < menuBajuPengantin.size(); i++) {
            System.out.println(i + ". " + menuBajuPengantin.get(i));
          }

          System.out.println();
          System.out.println("------------------o0o--------------------");
          System.out.print("Pilihan Anda: ");
          int pilihanMenuBajuPengantin = inputan.nextInt();
          System.out.println("------------------o0o--------------------");
          System.out.println();

          if (pilihanMenuBajuPengantin == 1) {
            String jenisSewa = "Baju Pengantin";
            String jenisMenuSewa = "Baju Pengantin Adat";

            System.out.print("Jam Sewa: ");
            int jamSewa = inputan.nextInt();

            sewa.Sewa(jenisSewa, jenisMenuSewa, sewa.getHargaSewa(), jamSewa);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + sewa.getHargaSewa());
          } else if (pilihanMenuBajuPengantin == 2) {
            String jenisSewa = "Baju Pengantin";
            String jenisMenuSewa = "Baju Pengantin Internasional";

            System.out.print("Jam Sewa: ");
            int jamSewa = inputan.nextInt();

            sewa.Sewa(jenisSewa, jenisMenuSewa, sewa.getHargaSewa(), jamSewa);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + sewa.getHargaSewa());
          }          
        } else if (pilihanMenuJenisSewa == 3) {
          System.out.println("===== Menu Aksesoris ======");

          for (int i = 1; i < menuAksesoris.size(); i++) {
            System.out.println(i + ". " + menuAksesoris.get(i));
          }

          System.out.println();
          System.out.println("------------------o0o--------------------");
          System.out.print("Pilihan Anda: ");
          int pilihanMenuAksesoris = inputan.nextInt();
          System.out.println("------------------o0o--------------------");
          System.out.println();

          if (pilihanMenuAksesoris == 1) {
            String jenisSewa = "Aksesoris";
            String jenisMenuSewa = "Aksesoris Anak";

            System.out.print("Jam Sewa: ");
            int jamSewa = inputan.nextInt();

            sewa.Sewa(jenisSewa, jenisMenuSewa, sewa.getHargaSewa(), jamSewa);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + sewa.getHargaSewa());
          } else if (pilihanMenuAksesoris == 2) {
            String jenisSewa = "Aksesoris";
            String jenisMenuSewa = "Aksesoris Dewasa";

            System.out.print("Jam Sewa: ");
            int jamSewa = inputan.nextInt();
            
            sewa.Sewa(jenisSewa, jenisMenuSewa, sewa.getHargaSewa(), jamSewa);
            
            System.out.println();
            System.out.println("------------------o0o--------------------");
            System.out.println("Data Tersimpan");
            System.out.println("------------------o0o--------------------");
            System.out.println();
            System.out.println("Harga Sebesar Rp. " + sewa.getHargaSewa());
          }
        }
      }
    }
  }
}