package v2;

public class Perawatan {
  private String jenisPerawatan;
  private String jenisMenuPerawatan;
  private int hargaPerawatan;
  private int jumlahOrang;

  public void Perawatan(String jenisPerawatan, String jenisMenuPerawatan, int hargaPerawatan, int jumlahOrang) {
    this.jenisPerawatan = jenisPerawatan;
    this.jenisMenuPerawatan = jenisMenuPerawatan;
    this.hargaPerawatan = hargaPerawatan;
    this.jumlahOrang = jumlahOrang;

    if (jenisPerawatan.equals("Facial Wajah")) {
      jenisPerawatan = "Facial Wajah";

      if (jenisMenuPerawatan.equals("Facial Biasa")) {
        jenisMenuPerawatan = "Facial Biasa";
        hargaPerawatan = 50000;
      } else if (jenisMenuPerawatan.equals("Facial Emas")) {
        jenisMenuPerawatan = "Facial Emas";
        hargaPerawatan = 100000;
      }
    } else if (jenisPerawatan.equals("Masker")) {
      jenisPerawatan = "Masker";

      if (jenisMenuPerawatan.equals("Masker Buah")) {
        jenisMenuPerawatan = "Masker Buah";
        hargaPerawatan = 40000;
      } else if (jenisMenuPerawatan.equals("Masker Lumpur")) {
        jenisMenuPerawatan = "Masker Lumpur";
        hargaPerawatan = 75000;
      }
    } else if (jenisPerawatan.equals("Potong Rambut")) {
      jenisPerawatan = "Potong Rambut";

      if (jenisMenuPerawatan.equals("Tidak Keramas")) {
        jenisMenuPerawatan = "Tidak Keramas";
        hargaPerawatan = 20000;
      } else if (jenisMenuPerawatan.equals("Keramas")) {
        jenisMenuPerawatan = "Keramas";
        hargaPerawatan = 35000;
      }
    }
  }

  public String getJenisPerawatan() {
    return jenisPerawatan;
  }

  public String getJenisMenuPerawatan() {
    return jenisMenuPerawatan;
  }

  public int getHargaPerawatan() {
    return hargaPerawatan;
  }

  public int getJumlahOrang() {
    return jumlahOrang;
  }

  public int totalHargaPerawatan() {
    return hargaPerawatan * jumlahOrang;
  }
}